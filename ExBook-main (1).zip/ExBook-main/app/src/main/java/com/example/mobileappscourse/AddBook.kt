package com.example.mobileappscourse

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.example.mobileappscourse.book.Book
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class AddBook : AppCompatActivity() {

    lateinit var currentUser : FirebaseUser

    lateinit var storage : FirebaseStorage
    lateinit var storageRef : StorageReference
    lateinit var firebaseDatabase: FirebaseDatabase
    lateinit var databaseReference: DatabaseReference

    private var bookCoverUri : Uri? = null
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_book)

        currentUser = Firebase.auth.currentUser!!


        storage = Firebase.storage
        storageRef = storage.reference
        firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase.reference
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        addBook()
        bookCoverSelect()
    }

    private fun bookCoverSelect() {
        val bookCoverImage : ImageView = findViewById(R.id.bookCoverSelect)

        bookCoverImage.setOnClickListener {
            openGallery()
        }
    }

    private fun openGallery() {
        val galleryIntent : Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent,
            100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == 100
            && data != null
            && data.data != null
        ) {
            val imageUri : Uri = data.data!!
            bookCoverUri = imageUri
            findViewById<ImageView>(R.id.bookCoverSelect).setImageURI(imageUri)
        }
    }

    @SuppressLint("MissingPermission")
    private fun addBook() {
        val titleField : EditText = findViewById(R.id.bookTitleEdit)
        val authorField : EditText = findViewById(R.id.bookAuthorEdit)
        val descField : EditText = findViewById(R.id.bookDescEdit)
        val submitBookBtn : Button = findViewById(R.id.submitBtnBook)

        submitBookBtn.setOnClickListener {
            if (bookCoverUri != null) {
                if (ActivityCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    Log.d("User location", "Have permission")
                    fusedLocationProviderClient.lastLocation.addOnSuccessListener {
                        addDataToFirebase(
                            currentUser.uid, titleField.text.toString(), authorField.text.toString(),
                            descField.text.toString(), LatLng(it.latitude, it.longitude))
                    }.addOnFailureListener {
                        Toast.makeText(this@AddBook, "Failed to access current location", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 44)
                    Toast.makeText(this@AddBook, "Rejected location permissions", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this@AddBook, "Select an image first", Toast.LENGTH_SHORT).show()
            }

        }

    }

    private fun addDataToFirebase(owner: String, bookTitle: String, author: String, description: String, currLocation: LatLng) {
        val dbKey = databaseReference.child("Book").push().key!!

        val coverRef = storageRef.child("$owner/$dbKey.jpg")

        coverRef.putFile(bookCoverUri!!)
            .addOnFailureListener {
                Toast.makeText(this, "Internal error", Toast.LENGTH_LONG).show()
            }.addOnSuccessListener {
                Toast.makeText(this, "Book posted", Toast.LENGTH_LONG).show()
            }

        databaseReference.child("Book").child(dbKey).setValue(Book(owner, "$owner/$dbKey.jpg", bookTitle, author, description,
            currLocation))

        databaseReference.child("user").child(owner).child("books").child(dbKey).setValue(bookTitle)

        finish()
    }
}