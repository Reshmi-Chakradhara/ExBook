package com.example.mobileappscourse

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class ProfileActivity : AppCompatActivity() {

    lateinit var user: FirebaseUser
    lateinit var dbReference: DatabaseReference
    lateinit var database: FirebaseDatabase
    lateinit var storage : FirebaseStorage
    lateinit var storageRef : StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val bottomNavigation : BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigation.setOnNavigationItemSelectedListener(navigation)

        var mailFromLoginActivity = intent.getStringExtra("mail")
        var passwordFromLoginActivity = intent.getStringExtra("password")

        storage = Firebase.storage
        storageRef = storage.reference

        user = Firebase.auth.currentUser!!

        database = FirebaseDatabase.getInstance()
        dbReference = database.reference

        val profileNameData : TextView = findViewById(R.id.profileNameData)
        val currentUserDb = dbReference.child("user").child(user.uid)

        currentUserDb.child("firstName").get().addOnSuccessListener {
            profileNameData.text = it.value.toString()
        }.addOnFailureListener {
            Toast.makeText(this@ProfileActivity, "Could not fetch data", Toast.LENGTH_LONG).show()
        }

        currentUserDb.child("surname").get().addOnSuccessListener {
            profileNameData.append(" " + it.value.toString())
        }.addOnFailureListener {
            Toast.makeText(this@ProfileActivity, "Could not fetch data", Toast.LENGTH_LONG).show()
        }

        val profileInfoBtn : Button = findViewById(R.id.personalInfoBtn)

        profileInfoBtn.setOnClickListener {
            startActivity(Intent(this@ProfileActivity, ProfileInfoActivity::class.java))
        }

        val settingsBtn : Button = findViewById(R.id.settingsBtn)

        settingsBtn.setOnClickListener {
            val intent = Intent(this@ProfileActivity, SettingsActivity::class.java)
            intent.putExtra("email", mailFromLoginActivity)
            intent.putExtra("password", passwordFromLoginActivity)
            startActivity(intent)
        }

        val libraryBtn : Button = findViewById(R.id.libraryBtn)

        libraryBtn.setOnClickListener {
            startActivity(Intent(this@ProfileActivity, LibraryActivity::class.java))
        }

        val pictureReference = storageRef.child("users").child(user.uid.toString() + ".jpg")
        val ONE_MB : Long = 1024*1024
        pictureReference.getBytes(ONE_MB).addOnSuccessListener {
            val bmp : Bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
            findViewById<ImageView>(R.id.profilePicture).setImageBitmap(bmp)
        }
    }

    override fun onRestart() {
        super.onRestart()

        val pictureReference = storageRef.child("users").child(user.uid.toString() + ".jpg")
        val ONE_MB : Long = 1024*1024
        pictureReference.getBytes(ONE_MB).addOnSuccessListener {
            val bmp : Bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
            findViewById<ImageView>(R.id.profilePicture).setImageBitmap(bmp)
        }
    }

    val navigation = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.ic_profile -> {
                return@OnNavigationItemSelectedListener false
            }
            R.id.ic_chat -> {
                val intent = Intent(this@ProfileActivity, ChatActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.ic_map -> {
                val intent = Intent(this@ProfileActivity, MapsActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.ic_search -> {
                // TODO: Replace by the name of the search activity
                //val intent = Intent(this@ProfileActivity, SearchActivity::class.java)
                //startActivity(intent)
                // TODO: Replace by true
                return@OnNavigationItemSelectedListener false
            }
        }
        false
    }
}
