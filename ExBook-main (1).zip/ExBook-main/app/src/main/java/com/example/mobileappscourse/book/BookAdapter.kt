package com.example.mobileappscourse.book

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mobileappscourse.R
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage

class BookAdapter(var context: Context) : RecyclerView.Adapter<BookAdapter.ViewHolder>() {

    var bookList = ArrayList<Book>()

    internal fun setBookList(bookList : ArrayList<Book>) {
        this.bookList = bookList
    }

    class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        var image : ImageView = itemView.findViewById(R.id.bookCover)
        var title : TextView = itemView.findViewById(R.id.bookTitle)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.book_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = bookList[position]
        val storage = Firebase.storage
        val storageRef = storage.reference

        holder.title.text = data.bookTitle

        val pictureReference = storageRef.child(data.photoPath)
        val ONE_MB : Long = 1024*1024
        pictureReference.getBytes(ONE_MB).addOnSuccessListener {
            val bmp : Bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
            holder.image.setImageBitmap(bmp)
        }
    }

    override fun getItemCount(): Int {
        return bookList.size
    }


}