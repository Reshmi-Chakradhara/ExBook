package com.example.mobileappscourse

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class ProfileInfoActivity : AppCompatActivity() {

    lateinit var user: FirebaseUser
    lateinit var dbReference: DatabaseReference
    lateinit var database: FirebaseDatabase
    lateinit var storage : FirebaseStorage
    lateinit var storageRef : StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_info)

        user = Firebase.auth.currentUser!!

        database = FirebaseDatabase.getInstance()
        dbReference = database.reference

        storage = Firebase.storage
        storageRef = storage.reference

        val genreSpinner1 : Spinner = findViewById(R.id.genre1Spinner)
        val genreSpinner2 : Spinner = findViewById(R.id.genre2Spinner)
        val genreSpinner3 : Spinner = findViewById(R.id.genre3Spinner)

        ArrayAdapter.createFromResource(
            this,
            R.array.genre_array,
            android.R.layout.simple_spinner_item
        ).also { arrayAdapter ->
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            genreSpinner1.adapter = arrayAdapter
            genreSpinner2.adapter = arrayAdapter
            genreSpinner3.adapter = arrayAdapter
        }

        changeProfilePic()

        val pictureReference = storageRef.child("users").child(user.uid.toString() + ".jpg")
        val ONE_MB : Long = 1024*1024
        pictureReference.getBytes(ONE_MB).addOnSuccessListener {
            val bmp : Bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
            findViewById<ImageView>(R.id.profilePictureChange).setImageBitmap(bmp)
        }
    }

    private fun changeProfilePic() {
        val profilePicture : ImageView = findViewById(R.id.profilePictureChange)

        profilePicture.setOnClickListener {
            openGallery()
        }
    }

    private fun openGallery() {
        val galleryIntent : Intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent,
            100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == 100
            && data != null
            && data.data != null
        ) {
            val imageUri : Uri = data.data!!
            uploadImage(imageUri)
        }
    }

    private fun uploadImage(filePath : Uri) {
        if (filePath != null) {
            val pictureReference = storageRef.child("users").child(user.uid.toString() + ".jpg")

            pictureReference.putFile(filePath)
                .addOnFailureListener {
                    Toast.makeText(this@ProfileInfoActivity, "File not uploaded", Toast.LENGTH_LONG)
                        .show()
                }.addOnSuccessListener {
                    val ONE_MB : Long = 1024*1024
                    pictureReference.getBytes(ONE_MB).addOnSuccessListener {
                        val bmp : Bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
                        findViewById<ImageView>(R.id.profilePictureChange).setImageBitmap(bmp)
                    }
                    Toast.makeText(this@ProfileInfoActivity, "File uploaded", Toast.LENGTH_LONG).show()
            }
        }
    }
}