package com.example.mobileappscourse

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobileappscourse.book.Book
import com.example.mobileappscourse.book.BookAdapter
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class LibraryActivity : AppCompatActivity() {

    lateinit var bookAdapter: BookAdapter
    lateinit var currentUser: FirebaseUser
    private var userLibrary = ArrayList<Book>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)

        val recyclerView : RecyclerView = findViewById(R.id.bookRView)
        val addBookBtn : Button = findViewById(R.id.addBookBtn)

        currentUser = Firebase.auth.currentUser!!

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        bookAdapter = BookAdapter(this)
        bookAdapter.setBookList(userLibrary)
        recyclerView.adapter = bookAdapter

        downloadUserBooks()

        addBookBtn.setOnClickListener {
            startActivity(Intent(this@LibraryActivity, AddBook::class.java))
        }
    }

    override fun onRestart() {
        super.onRestart()
        userLibrary.clear()
        downloadUserBooks()
    }

    private fun downloadUserBooks() {
        val userDbRef = FirebaseDatabase
            .getInstance()
            .getReference("user")
            .child(currentUser.uid)

        val bookDbRef = FirebaseDatabase
            .getInstance()
            .getReference("Book")

        val bookListener  = object : ValueEventListener {
            @SuppressLint("NotifyDataSetChanged")
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (data : DataSnapshot in snapshot.children) {
                        val bookKey = data.key!!
                        var owner = ""
                        var photoPath = ""
                        var bookTitle = ""
                        var author = ""
                        var description = ""
                        var location: LatLng? = null

                        bookDbRef.child(bookKey).child("owner").get().addOnSuccessListener {
                            owner = it.value.toString()

                            bookDbRef.child(bookKey).child("photoPath").get().addOnSuccessListener { it2 ->
                                photoPath = it2.value.toString()

                                bookDbRef.child(bookKey).child("bookTitle").get().addOnSuccessListener { it3 ->
                                    bookTitle = it3.value.toString()

                                    bookDbRef.child(bookKey).child("author").get().addOnSuccessListener { it4 ->
                                        author = it4.value.toString()

                                        bookDbRef.child(bookKey).child("description").get().addOnSuccessListener { it5 ->
                                            description = it5.value.toString()

                                            bookDbRef.child(bookKey).child("location").get().addOnSuccessListener { it6 ->
                                                val hashMap = it6.value as HashMap<*, *>
                                                location = LatLng(hashMap["latitude"].toString().toDouble(),
                                                    hashMap["longitude"].toString().toDouble())
                                                Log.d("Location", location.toString())

                                                if (owner == "" || photoPath == "" || bookTitle == "" || author == "" || description == "") {
                                                    Log.d("owner", owner)
                                                    Log.d("photoPath", photoPath)
                                                    Log.d("bookTitle", bookTitle)
                                                    Log.d("author", author)
                                                    Log.d("description", description)
                                                    Toast.makeText(this@LibraryActivity,
                                                        "Failed to retrieve data",
                                                        Toast.LENGTH_LONG).show()
                                                } else {
                                                    userLibrary.add(
                                                        Book(
                                                            owner,
                                                            photoPath,
                                                            bookTitle,
                                                            author,
                                                            description,
                                                            location!!
                                                        )
                                                    )
                                                    bookAdapter.notifyDataSetChanged()
                                                }
                                            }.addOnFailureListener {
                                                location = null
                                            }
                                        }.addOnFailureListener {
                                            description = ""
                                        }
                                    }.addOnFailureListener {
                                        author = ""
                                    }
                                }.addOnFailureListener {
                                    bookTitle = ""
                                }
                            }.addOnFailureListener {
                                photoPath = ""
                            }
                        }.addOnFailureListener {
                            owner = ""
                        }

                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@LibraryActivity, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
        }

        userDbRef.child("books").addListenerForSingleValueEvent(bookListener)
    }
}