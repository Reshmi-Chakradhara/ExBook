package com.example.mobileappscourse

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class RegisterActivity : AppCompatActivity() {

    lateinit var auth : FirebaseAuth
    lateinit var dbReference: DatabaseReference
    lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // to remove the action bar
        supportActionBar?.hide()

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        dbReference = database.reference

        createUser()
    }

    private fun createUser() {
        val registerBtn = findViewById<Button>(R.id.registerBtn)
        val userFirstName = findViewById<EditText>(R.id.firstNameR)
        val userSurname = findViewById<EditText>(R.id.surnameR)
        val userEmail = findViewById<EditText>(R.id.emailR)
        val userPassword = findViewById<EditText>(R.id.passwordR)

        registerBtn.setOnClickListener {
            when {
                TextUtils.isEmpty(userFirstName.text.toString()) -> {
                    userFirstName.error = "Enter first name"
                    return@setOnClickListener
                }
                TextUtils.isEmpty(userSurname.text.toString()) -> {
                    userSurname.error = "Enter surname"
                    return@setOnClickListener
                }
                TextUtils.isEmpty(userEmail.text.toString()) -> {
                    userEmail.error = "Enter e-mail"
                    return@setOnClickListener
                }
                TextUtils.isEmpty(userPassword.text.toString()) -> {
                    userPassword.error = "Enter password"
                    return@setOnClickListener
                }


                else -> auth.createUserWithEmailAndPassword(userEmail.text.toString(), userPassword.text.toString())
                    .addOnCompleteListener(this) {
                        if(it.isSuccessful) {

                            //val currentUser = auth.currentUser
                            //val userDb = dbReference.child("User").child(currentUser?.uid!!)

                            //userDb.child("USR_NAME").setValue(userFirstName.text.toString())
                            //userDb.child("USR_SURNAME").setValue(userSurname.text.toString())

                            //Toast.makeText(this, "Registration successful", Toast.LENGTH_LONG).show()
                            //finish()

                            dbReference = FirebaseDatabase.getInstance().getReference()
                            dbReference.child("user").child(auth.currentUser?.uid!!)
                                .setValue(User(userFirstName.text.toString(), userSurname.text.toString(), userEmail.text.toString(), auth.currentUser?.uid!!))

                            val intent = Intent(this@RegisterActivity, ProfileActivity::class.java)
                            startActivity(intent)

                        } else {
                            Toast.makeText(this@RegisterActivity, "Internal error", Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }
    }
}