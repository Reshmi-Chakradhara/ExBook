package com.example.mobileappscourse

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    lateinit var auth : FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // to remove the action bar
        supportActionBar?.hide()

        auth = FirebaseAuth.getInstance()

        loginUser()

        val signUpActivityBtn = findViewById<Button>(R.id.signupBtn)

        signUpActivityBtn.setOnClickListener {
            startActivity(Intent(this@LoginActivity, RegisterActivity::class.java))
        }
    }

    private fun loginUser() {
        val loginBtn = findViewById<Button>(R.id.loginBtn)
        val userEmail = findViewById<EditText>(R.id.emailL)
        val userPassword = findViewById<EditText>(R.id.passwordL)

        loginBtn.setOnClickListener {
            when {
                TextUtils.isEmpty(userEmail.text.toString()) -> {
                    userEmail.error = "Enter e-mail"
                    return@setOnClickListener
                }
                TextUtils.isEmpty(userPassword.text.toString()) -> {
                    userPassword.error = "Enter password"
                    return@setOnClickListener
                }
                else -> auth.signInWithEmailAndPassword(userEmail.text.toString(), userPassword.text.toString())
                    .addOnCompleteListener(this) {
                        if( it.isSuccessful) {
                            val intent = Intent(this@LoginActivity, ProfileActivity::class.java)
                            intent.putExtra("mail", userEmail.text.toString())
                            intent.putExtra("password", userPassword.text.toString())
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }
    }
}