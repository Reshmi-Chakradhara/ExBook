package com.example.mobileappscourse.book

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import com.example.mobileappscourse.R
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.Marker

class MarkerInfoWindowAdapter(
    private val context: Context
) : GoogleMap.InfoWindowAdapter {
    override fun getInfoContents(marker: Marker): View? {
        val book = marker.tag as? Book ?: return null

        val view = LayoutInflater.from(context).inflate(
            R.layout.marker_info_contents, null
        )

        view.findViewById<TextView>(
            R.id.text_view_title
        ).text = book.bookTitle
        view.findViewById<TextView>(
            R.id.text_view_author
        ).text = book.author

        return view
    }

    override fun getInfoWindow(marker: Marker): View? {
        return null
    }
}