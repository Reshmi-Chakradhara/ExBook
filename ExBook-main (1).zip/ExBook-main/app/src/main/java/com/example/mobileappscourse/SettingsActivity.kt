package com.example.mobileappscourse

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage

class SettingsActivity : AppCompatActivity() {
    lateinit var user : FirebaseUser

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        user = Firebase.auth.currentUser!!

        switchTheme()
        changePassword()
        deleteUser()
        logoutUser()
    }

    private fun changePassword() {
        val passwordField : EditText = findViewById(R.id.passwordChangeEdit)
        val passwordChangeBtn : Button = findViewById(R.id.passwordChangeBtn)

        val credentials = EmailAuthProvider.getCredential(intent.getStringExtra("email")!!,
            intent.getStringExtra("password")!!)

        passwordChangeBtn.setOnClickListener {
            user.reauthenticate(credentials).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    user.updatePassword(passwordField.text.toString()).addOnCompleteListener {
                        if (it.isSuccessful) {
                            Toast.makeText(
                                this@SettingsActivity,
                                "Password changed",
                                Toast.LENGTH_LONG
                            ).show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        } else {
                            Toast.makeText(
                                this@SettingsActivity,
                                "Internal server error",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } else {
                    Toast.makeText(this@SettingsActivity, "Re-auth failed", Toast.LENGTH_LONG).show()
                }
            }
        }

    }

    private fun switchTheme(){

        val themeSwitch : Switch = findViewById(R.id.themeSwitch)

        themeSwitch.setOnCheckedChangeListener { _, isChecked ->
            if(isChecked){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }

    private fun deleteUser() {
        val deleteBtn : Button = findViewById(R.id.deleteAccBtn)

        val credentials = EmailAuthProvider.getCredential(intent.getStringExtra("email")!!,
            intent.getStringExtra("password")!!)

        deleteBtn.setOnClickListener {
            user.reauthenticate(credentials).addOnCompleteListener { task ->
                if(task.isSuccessful) {
                    user.delete().addOnCompleteListener {
                        if(it.isSuccessful) {
                            Toast.makeText(this@SettingsActivity, "User deleted", Toast.LENGTH_LONG).show()
                            startActivity(Intent(this, LoginActivity::class.java))
                            finish()
                        } else {
                            Toast.makeText(this@SettingsActivity, "Internal server error", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Toast.makeText(this@SettingsActivity, "Re-auth failed", Toast.LENGTH_LONG).show()
                }
            }

        }
    }

    private fun logoutUser() {
        val logoutBtn : Button = findViewById(R.id.LogoutBtn)

        logoutBtn.setOnClickListener {
            Firebase.auth.signOut()
            Toast.makeText(this@SettingsActivity, "Logged out", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}