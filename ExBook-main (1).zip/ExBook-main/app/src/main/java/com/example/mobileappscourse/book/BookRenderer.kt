package com.example.mobileappscourse.book

import android.content.Context
import androidx.core.content.ContextCompat
import com.example.mobileappscourse.R
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.clustering.ClusterManager
import com.google.maps.android.clustering.view.DefaultClusterRenderer

class BookRenderer(
    context: Context,
    map: GoogleMap,
    clusterManager: ClusterManager<Book>
) : DefaultClusterRenderer<Book>(context, map, clusterManager) {

    private val ic_book_mark: BitmapDescriptor by lazy {
        val color = ContextCompat.getColor(context,
            R.color.orange_secondary
        )
        BitmapHelper.vectorToBitmap(
            context,
            R.drawable.ic_book_mark,
            color
        )
    }
    override fun onBeforeClusterItemRendered(item: Book, markerOptions: MarkerOptions) {
        markerOptions.title(item.bookTitle)
            .position(item.location)
            .icon(ic_book_mark)
    }

    override fun onClusterItemRendered(clusterItem: Book, marker: Marker) {
        marker.tag = clusterItem
    }
}