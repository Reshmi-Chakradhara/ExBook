package com.example.mobileappscourse

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import com.example.mobileappscourse.book.Book
import com.example.mobileappscourse.book.BookRenderer
import com.example.mobileappscourse.book.BooksHandler
import com.example.mobileappscourse.book.MarkerInfoWindowAdapter
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import com.google.maps.android.clustering.ClusterManager

class MapsActivity : AppCompatActivity() {
    private var supportMapFragment: SupportMapFragment? = null
    private var client: FusedLocationProviderClient? = null
    private var books: ArrayList<Book>? = null
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val bottomNavigation : BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigation.setOnNavigationItemSelectedListener(navigation)

        supportMapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase.getReference("Book")

        client = LocationServices.getFusedLocationProviderClient(this)
        checkPermissions()
        books = arrayListOf()
        readDataFromFirebase()
    }

    private fun addClusteredMarkers(googleMap: GoogleMap) {
        val clusterManager = ClusterManager<Book>(this, googleMap)
        clusterManager.renderer =
            BookRenderer(
                this,
                googleMap,
                clusterManager
            )

        clusterManager.markerCollection.setInfoWindowAdapter(MarkerInfoWindowAdapter(this))
        Log.i("Map", books.toString())
        clusterManager.addItems(books)
        clusterManager.cluster()
    }

    private fun checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 44)
        }
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        val task: Task<Location> = client!!.lastLocation
        task.addOnSuccessListener {
            val locationData = it
            supportMapFragment?.getMapAsync { it2 ->
                val userLocation = LatLng(locationData.latitude, locationData.longitude)
                val options = MarkerOptions().position(userLocation).title("You are here")

                it2.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 10F))
                it2.addMarker(options);
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                getCurrentLocation()
            }
        }
    }

    private fun readDataFromFirebase() {
        val bookListener = object: ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (data: DataSnapshot in snapshot.children) {
                        Log.i("Snapshot", data.value.toString())
                        val hashMap = data.value as HashMap<*, *>
                        if (hashMap["owner"] != Firebase.auth.currentUser!!.uid) {
                            val owner = hashMap["owner"] as String
                            val photoPath = hashMap["photoPath"] as String
                            val bookTitle = hashMap["bookTitle"] as String
                            val author = hashMap["author"] as String
                            val description = hashMap["description"] as String
                            val locationMap = hashMap["location"] as HashMap<*, *>
                            val location = LatLng(locationMap["latitude"].toString().toDouble(),
                                locationMap["longitude"].toString().toDouble())
                            books?.add(Book(owner, photoPath, bookTitle, author, description, location))
                        }
                    }
                    supportMapFragment?.getMapAsync { googleMap ->
                        addClusteredMarkers(googleMap)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
            }
        }
        databaseReference.addListenerForSingleValueEvent(bookListener)
    }

    val navigation = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.ic_map -> {
                return@OnNavigationItemSelectedListener false
            }
            R.id.ic_chat -> {
                val intent = Intent(this@MapsActivity, ChatActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.ic_profile -> {
                val intent = Intent(this@MapsActivity, ProfileActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.ic_search -> {
                // TODO: Replace by the name of the search activity
                //val intent = Intent(this@ProfileActivity, SearchActivity::class.java)
                //startActivity(intent)
                // TODO: Replace by true
                return@OnNavigationItemSelectedListener false
            }
        }
        false
    }
}