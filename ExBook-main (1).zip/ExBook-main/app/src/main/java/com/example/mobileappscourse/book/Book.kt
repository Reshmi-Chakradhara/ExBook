package com.example.mobileappscourse.book

import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem

data class Book(
    val owner: String,
    val photoPath: String,
    val bookTitle: String,
    val author: String,
    val description: String,
    val location: LatLng,
): ClusterItem {
    override fun getPosition(): LatLng =
        location

    override fun getTitle(): String =
        bookTitle

    override fun getSnippet(): String =
        author
}