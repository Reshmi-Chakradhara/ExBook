package com.example.mobileappscourse

/**
 * Created by {USER} on {DATE}
 */
class User {
    var firstName: String? = null
    var surname: String? = null
    var email: String? = null
    var uid: String? = null

    constructor(){}

    constructor(firstName: String?, surname: String?, email: String?, uid: String?){
        this.firstName = firstName
        this.surname = surname
        this.email = email
        this.uid = uid
    }
}