package com.example.mobileappscourse.book

import android.util.Log
import android.widget.Toast
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.database.*


class BooksHandler {



}