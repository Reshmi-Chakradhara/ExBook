# ExBook

To be able to use map you have to go to Tools > SDK Manager, then go to SDK Tools packages and install (probably both, not tested yet):

```
Google Play Licensing Library
Google Play services
```

Then you have to add GOOGLE_MAPS_KEY to local.properites file
```
GOOGLE_MAPS_KEY=<HERE_GOES_KEY>
```
To get the key go to https://console.cloud.google.com/ change account to the account you have used to access FireBase, on the left you can show menu click there APIs & Services
then go to Credentials page and copy the API Key.
